const fs = require('fs');
const path = require('path');

const qrDir = path.join(__dirname, 'uploads', 'qr');
if (!fs.existsSync(qrDir)) fs.mkdirSync(qrDir, { recursive: true });

const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 320" width="320" height="320">
  <defs>
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#4f46e5;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="320" height="320" fill="#ffffff" rx="20" stroke="#e2e8f0" stroke-width="2"/>
  
  <!-- Outer Corners -->
  <rect x="25" y="25" width="75" height="75" fill="#0f172a" rx="10"/>
  <rect x="35" y="35" width="55" height="55" fill="#ffffff" rx="6"/>
  <rect x="47" y="47" width="31" height="31" fill="#4f46e5" rx="4"/>
  
  <rect x="220" y="25" width="75" height="75" fill="#0f172a" rx="10"/>
  <rect x="230" y="35" width="55" height="55" fill="#ffffff" rx="6"/>
  <rect x="242" y="47" width="31" height="31" fill="#4f46e5" rx="4"/>

  <rect x="25" y="220" width="75" height="75" fill="#0f172a" rx="10"/>
  <rect x="35" y="230" width="55" height="55" fill="#ffffff" rx="6"/>
  <rect x="47" y="242" width="31" height="31" fill="#4f46e5" rx="4"/>

  <!-- QR Pattern Blocks -->
  <rect x="120" y="30" width="20" height="20" fill="#0f172a" />
  <rect x="150" y="40" width="25" height="30" fill="#0f172a" />
  <rect x="180" y="30" width="20" height="40" fill="#0f172a" />
  
  <rect x="30" y="120" width="30" height="20" fill="#0f172a" />
  <rect x="70" y="130" width="35" height="35" fill="#0f172a" />
  
  <!-- Center UPI badge -->
  <rect x="120" y="120" width="80" height="80" fill="url(#grad1)" rx="14"/>
  <text x="160" y="155" font-family="Arial, sans-serif" font-weight="900" font-size="16" fill="#ffffff" text-anchor="middle">SCAN &amp; PAY</text>
  <text x="160" y="175" font-family="Arial, sans-serif" font-weight="bold" font-size="11" fill="#f8fafc" text-anchor="middle">UPI / QR CODE</text>

  <rect x="220" y="120" width="40" height="20" fill="#0f172a" />
  <rect x="270" y="130" width="25" height="30" fill="#0f172a" />
  <rect x="220" y="160" width="30" height="40" fill="#0f172a" />
  <rect x="265" y="175" width="30" height="25" fill="#0f172a" />

  <rect x="120" y="220" width="25" height="35" fill="#0f172a" />
  <rect x="160" y="230" width="40" height="25" fill="#0f172a" />
  <rect x="220" y="220" width="75" height="20" fill="#0f172a" />
  <rect x="240" y="250" width="55" height="45" fill="#0f172a" />
  <rect x="120" y="270" width="40" height="25" fill="#0f172a" />
  <rect x="175" y="265" width="35" height="30" fill="#0f172a" />

  <text x="160" y="308" font-family="Arial, sans-serif" font-weight="bold" font-size="10" fill="#64748b" text-anchor="middle">Google Pay | PhonePe | Paytm | BHIM</text>
</svg>`;

fs.writeFileSync(path.join(qrDir, 'default_qr.svg'), svg);
console.log('Default QR SVG created successfully');
